from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI()

class FlightQuery(BaseModel):
    from_: str
    to: str
    departDate: str
    returnDate: str = None
    adults: int = 1

@app.post("/api/search-flights")
def search_flights(query: FlightQuery):
    return [{
        'airline': 'DemoAir',
        'from': query.from_,
        'to': query.to,
        'price': '₹5999',
        'depart': query.departDate
    }]
